package com.example.libreria_in_47_app.interfaces;

public interface ILanguage {
    int getId();
    String getName();
}