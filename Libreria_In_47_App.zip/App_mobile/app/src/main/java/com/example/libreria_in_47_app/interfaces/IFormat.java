package com.example.libreria_in_47_app.interfaces;

public interface IFormat {
    int getId();
    String getType();
}