package com.example.libreria_in_47_app.interfaces;

public interface ICategory {
    int getId();
    String getType();
}