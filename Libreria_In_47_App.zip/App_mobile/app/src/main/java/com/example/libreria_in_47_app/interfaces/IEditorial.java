package com.example.libreria_in_47_app.interfaces;

public interface IEditorial {
    int getId();
    String getName();
}
