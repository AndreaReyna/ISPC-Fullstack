package com.example.libreria_in_47_app.interfaces;

public interface IUser {

    int getIdUser();

    String getNombre();

    String getApellido();

    String getPassword();

    String getTipo_usuario();

    String getEmail();

    String getDni();

    String getFecha_nac();

    String getTelefono();

    String getFecha_creacion();

    String getFecha_modificacion();
}
