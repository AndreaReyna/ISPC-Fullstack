package com.example.libreria_in_47_app.interfaces;

public interface IAuthor {
    int getId();
    String getFullName();
}